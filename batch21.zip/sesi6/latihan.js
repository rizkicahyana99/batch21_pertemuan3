
document.write('Hello, World!');
document.write('<b>Hello, World Tebal..!</b>');
document.write('<h2>Judul Halaman</h2>');
document.write('<div id="kotak1"></div>');
document.write('<div id="kotak2"></div>');
document.getElementById('kotak1').style.background = 'yellow';
document.getElementById('kotak1').style.width = '100%';
document.getElementById('kotak1').append("Hello... saya di Kotak 1");
document.getElementById('kotak1').style.height = '5em';
// menghapus elemen html
document.getElementById('kotak1').remove();